<?php
// user/index.php - Dashboard pengguna untuk sistem SaaS
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/Auth.php';

// Mulai sesi
session_start();

// Inisialisasi Auth
$auth = new Auth();

// Cek apakah pengguna sudah login
$userData = $auth->isLoggedIn();
if (!$userData) {
    // Redirect ke halaman login
    header('Location: ../login.php');
    exit;
}

// Inisialisasi database
$db = Database::getInstance();

// Ambil pengaturan pengguna
$userSettings = $db->fetchOne("SELECT * FROM user_settings WHERE user_id = ?", [$userData['user_id']]);

// Ambil data statistik log
$today = date('Y-m-d');
$todayLoginCount = $db->fetchColumn(
    "SELECT COUNT(*) FROM pppoe_logs WHERE user_id = ? AND event_type = 'login' AND event_date = ?", 
    [$userData['user_id'], $today]
);
$todayLogoutCount = $db->fetchColumn(
    "SELECT COUNT(*) FROM pppoe_logs WHERE user_id = ? AND event_type = 'logout' AND event_date = ?", 
    [$userData['user_id'], $today]
);

// Ambil log terbaru (10 terakhir)
$recentLogs = $db->fetchAll(
    "SELECT * FROM pppoe_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 5", 
    [$userData['user_id']]
);

// Proses update pengaturan
$updateMessage = '';

// Ambil daftar admin
$adminList = $db->fetchAll("SELECT name, phone FROM admins");
require_once '../includes/PhoneUtils.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_settings'])) {
    $groupId = $_POST['group_id'] ?? '';
    
    // Update pengaturan
    $db->update(
        'user_settings',
        ['group_id' => $groupId],
        'user_id = ?',
        [$userData['user_id']]
    );
    
    // Refresh data
    $userSettings = $db->fetchOne("SELECT * FROM user_settings WHERE user_id = ?", [$userData['user_id']]);
    $updateMessage = 'Pengaturan berhasil diperbarui';
}

// Ambil script Mikrotik dengan token pengguna
$mikrotikScript = file_get_contents('../mikrotik_script.txt');
$mikrotikScript = str_replace('rahasia123', $userSettings['token'] ?? 'TOKEN_TIDAK_DITEMUKAN', $mikrotikScript);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - (NotMiK) Notification Mikrotik</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100 min-h-screen">
    <!-- Navbar -->
    <nav class="bg-green-600 text-white shadow-md">
    <div class="container mx-auto px-4 py-3 flex justify-between items-center">
        <div class="flex items-center">
            <span class="font-bold text-xl">(NotMiK) Notification Mikrotik</span>
        </div>
        <div class="flex items-center space-x-4">
            <span class="hidden md:inline-block"><?php echo htmlspecialchars($userData['name']); ?></span>
            <a href="./statistik.php" class="hover:underline">
            <i class="fas fa-chart-bar mr-1"></i> Statistik
            </a>
            <a href="../logout.php" class="hover:underline">
                <i class="fas fa-sign-out-alt mr-1"></i> Logout
            </a>
        </div>
    </div>
</nav>

    <!-- Main Content -->
    <div class="container mx-auto px-4 py-6">
<?php if ($userData['status'] === 'suspended'): ?>
    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-8 rounded-lg text-center mb-8">
        <i class="fas fa-ban fa-3x mb-4"></i>
        <h2 class="text-2xl font-bold mb-2">Akun Anda Ditangguhkan</h2>
        <p class="mb-2">Akun Anda sedang <span class="font-bold uppercase">suspend</span> oleh admin.</p>
        <p>Seluruh fitur notifikasi, pengaturan, dan script Mikrotik tidak dapat diakses sementara.</p>
        <p class="mt-4">Silakan hubungi admin untuk informasi lebih lanjut atau reaktivasi akun.</p>
    </div>
<?php else: ?>
        <!-- Welcome Message -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h1 class="text-2xl font-bold text-gray-800 mb-2">Selamat Datang, <?php echo htmlspecialchars($userData['name']); ?>!</h1>
            <p class="text-gray-600">Kelola notifikasi WhatsApp untuk Mikrotik Anda di sini.</p>
        </div>

        <!-- Status Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <!-- Login Today -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center">
                    <div class="p-3 rounded-full bg-blue-100 text-blue-500 mr-4">
                        <i class="fas fa-sign-in-alt"></i>
                    </div>
                    <div>
                        <p class="text-gray-500 text-sm">Login Hari Ini</p>
                        <p class="text-2xl font-bold"><?php echo $todayLoginCount; ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Logout Today -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center">
                    <div class="p-3 rounded-full bg-red-100 text-red-500 mr-4">
                        <i class="fas fa-sign-out-alt"></i>
                    </div>
                    <div>
                        <p class="text-gray-500 text-sm">Logout Hari Ini</p>
                        <p class="text-2xl font-bold"><?php echo $todayLogoutCount; ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Status -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center">
                    <div class="p-3 rounded-full bg-green-100 text-green-500 mr-4">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div>
                        <p class="text-gray-500 text-sm">Status Akun</p>
                        <p class="text-2xl font-bold"><?php echo ucfirst($userData['status']); ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Token -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center">
                    <div class="p-3 rounded-full bg-purple-100 text-purple-500 mr-4">
                        <i class="fas fa-key"></i>
                    </div>
                    <div>
                        <p class="text-gray-500 text-sm">Token</p>
                        <p class="text-lg font-bold truncate" title="<?php echo htmlspecialchars($userSettings['token'] ?? 'Tidak ada'); ?>">
                            <?php echo htmlspecialchars($userSettings['token'] ?? 'Tidak ada'); ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Settings -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Pengaturan</h2>
                <?php if ($userData['status'] === 'pending'): ?>
                    <div class="bg-yellow-100 border-l-4 border-yellow-400 text-yellow-800 p-6 rounded text-center">
                        <i class="fas fa-lock fa-2x mb-2"></i><br>
                        <span class="font-bold">Akun Anda masih dalam status <span class="uppercase">pending</span>.</span><br>
                        Pengaturan ID Grup WhatsApp dan informasi admin akan tersedia setelah akun Anda aktif.
                    </div>
                <?php else: ?>
                    <?php if ($updateMessage): ?>
                        <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
                            <?php echo $updateMessage; ?>
                        </div>
                    <?php endif; ?>
                    <form method="POST" class="space-y-4">
                        <div>
                            <label for="group_id" class="block text-gray-700 font-medium mb-2">ID Grup WhatsApp</label>
                            <input type="text" id="group_id" name="group_id" 
                                   value="<?php echo htmlspecialchars($userSettings['group_id'] ?? ''); ?>" 
                                   placeholder="Contoh: 120363408186330281@g.us" 
                                   class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
                            <div class="text-sm text-gray-700 mt-1">
                                <div class="bg-green-50 border border-green-200 rounded-lg p-4 mb-2">
                                    <div class="flex items-center mb-2">
                                        <span class="text-green-600 mr-2"><i class="fas fa-users fa-lg"></i></span>
                                        <span class="font-semibold">Cara Melihat ID Grup WhatsApp Web</span>
                                    </div>
                                    <ol class="list-decimal ml-6 space-y-1">
                                        <li>Buka <a href="https://web.whatsapp.com" target="_blank" class="text-green-700 underline font-semibold">WhatsApp Web <i class="fas fa-external-link-alt text-xs"></i></a></li>
                                        <li>Masuk ke grup yang diinginkan.</li>
                                        <li>Klik <span class="font-semibold">ikon profil grup</span> <i class="fas fa-user-circle"></i> (foto grup).</li>
                                        <li>Lihat URL di browser, misal:<br>
                                            <span class="bg-gray-100 px-2 py-1 rounded text-xs text-gray-700">https://web.whatsapp.com/send?groupchat&gid=120363408186330281@g.us</span>
                                        </li>
                                        <li>Salin bagian setelah <span class="bg-gray-200 px-1 rounded">gid=</span> (misal: <span class="bg-gray-100 px-1 rounded">120363408186330281@g.us</span>) dan masukkan ke field di atas.</li>
                                    </ol>
                                    <div class="mt-3 p-2 bg-yellow-50 border-l-4 border-yellow-400 text-yellow-800 rounded">
                                        <i class="fas fa-info-circle mr-1"></i>
                                        <span class="font-semibold">Tips:</span> Pastikan <span class="text-green-700 font-bold">nomor sender</span> sudah masuk ke grup agar bisa mengirim notifikasi secara realtime.
                                    </div>
                                </div>
                                <!-- Daftar admin -->
                                <div class="bg-white border border-gray-200 rounded-lg p-4 mt-2">
                                    <div class="flex items-center mb-2">
                                        <span class="text-blue-600 mr-2"><i class="fas fa-user-shield fa-lg"></i></span>
                                        <span class="font-semibold">Daftar Nomor WhatsApp Sender:</span>
                                    </div>
                                    <ul class="list-disc ml-6">
                                        <?php if (!empty($adminList)): ?>
                                            <?php foreach ($adminList as $admin): ?>
                                                <li class="mb-1">
                                                    <span class="font-semibold"><?php echo htmlspecialchars($admin['name']); ?>:</span>
                                                    <span class="text-blue-700">
                                                        <?php echo htmlspecialchars(PhoneUtils::format($admin['phone'] ?? '', true)); ?>
                                                    </span>
                                                </li>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <li class="text-gray-500">Belum ada admin terdaftar.</li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="update_settings" value="1">
                        <button type="submit" class="bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition duration-200">
                            Simpan Pengaturan
                        </button>
                    </form>
                <?php endif; ?>
            </div>

            <!-- Mikrotik Script -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Script Mikrotik</h2>
                <p class="text-gray-600 mb-4">Copy script berikut ke PPP Profile Script Mikrotik Anda untuk mengaktifkan notifikasi:</p>
                
                <div class="relative">
                    <?php if ($userData['status'] === 'pending'): ?>
                        <div class="bg-yellow-100 text-yellow-800 p-4 rounded mb-2 text-center">
                            <i class="fas fa-lock mr-1"></i> Akun Anda masih <span class="font-bold">pending</span>.<br>
                            Script Mikrotik akan muncul setelah akun Anda aktif.
                        </div>
                    <?php else: ?>
                        <pre class="bg-gray-100 p-4 rounded-lg text-sm overflow-x-auto"><?php echo htmlspecialchars($mikrotikScript); ?></pre>
                        <button id="copyBtn" class="absolute top-2 right-2 bg-green-600 text-white p-2 rounded hover:bg-green-700">
                            <i class="fas fa-copy"></i>
                        </button>
                    <?php endif; ?>
                </div>
                <p class="text-sm text-gray-500 mt-2">Script ini sudah berisi token unik Anda.</p>
            </div>
        </div>

        <!-- Recent Logs -->
        <div class="bg-white rounded-2xl shadow-lg p-8 mt-8">
            <div class="flex items-center mb-6">
                <div class="bg-green-100 text-green-700 rounded-full p-3 mr-3">
                    <i class="fas fa-history fa-lg"></i>
                </div>
                <h2 class="text-2xl font-extrabold text-gray-800 tracking-tight">Log Aktivitas Terbaru</h2>
            </div>
            <div class="overflow-x-auto">
                <?php if (empty($recentLogs)): ?>
                    <div class="flex flex-col items-center justify-center py-10">
                        <svg width="56" height="56" fill="none" viewBox="0 0 56 56" class="mb-3"><circle cx="28" cy="28" r="28" fill="#F3F4F6"/><path d="M28 16v12l8 4" stroke="#9CA3AF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        <p class="text-gray-500 text-lg">Belum ada aktivitas tercatat.</p>
                    </div>
                <?php else: ?>
                <table class="min-w-full divide-y divide-gray-100">
                    <thead>
                        <tr>
                            <th class="py-2 px-3 text-left text-xs font-semibold text-gray-500">Tanggal</th>
                            <th class="py-2 px-3 text-left text-xs font-semibold text-gray-500">Waktu</th>
                            <th class="py-2 px-3 text-left text-xs font-semibold text-gray-500">Event</th>
                            <th class="py-2 px-3 text-left text-xs font-semibold text-gray-500">Username</th>
                            <th class="py-2 px-3 text-left text-xs font-semibold text-gray-500">IP / Alasan</th>
                        </tr>
                    </thead>
                    <tbody id="logsTbody" class="divide-y divide-gray-50">
                        <?php
function format_tanggal_indo($tanggal) {
    setlocale(LC_TIME, 'id_ID.utf8', 'id_ID', 'IND');
    $bulan = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    $tgl = date('j', strtotime($tanggal));
    $bln = $bulan[(int)date('n', strtotime($tanggal))];
    $thn = date('Y', strtotime($tanggal));
    return $tgl . ' ' . $bln . ' ' . $thn;
}
?>
<?php foreach ($recentLogs as $log): ?>
                        <tr class="transition hover:bg-green-50/60 group">
                            <td class="py-2 px-3 align-top">
                                <span class="text-xs text-gray-400 font-mono block leading-tight">
                                    <i class="fas fa-calendar-alt mr-1"></i><?php echo format_tanggal_indo($log['event_date']); ?>
                                </span>
                            </td>
                            <td class="py-2 px-3 align-top">
                                <span class="text-xs text-gray-400 font-mono block leading-tight">
                                    <i class="fas fa-clock mr-1"></i><?php echo htmlspecialchars($log['event_time']); ?>
                                </span>
                            </td>
                            <td class="py-2 px-3 align-top">
                                <?php if ($log['event_type'] == 'login'): ?>
                                    <span class="inline-flex items-center px-2 py-1 rounded-full bg-green-100 text-green-700 text-xs font-bold gap-1">
                                        <i class="fas fa-sign-in-alt"></i> Login
                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center px-2 py-1 rounded-full bg-red-100 text-red-600 text-xs font-bold gap-1">
                                        <i class="fas fa-sign-out-alt"></i> Logout
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="py-2 px-3 align-top">
    <span class="font-semibold text-gray-800"><i class="fas fa-user mr-1 text-gray-400"></i><?php echo htmlspecialchars($log['username']); ?></span>
    <button type="button" class="ml-2 text-xs px-2 py-1 rounded bg-green-100 text-green-700 font-semibold hover:bg-green-200 focus:outline-none detail-btn" data-username="<?php echo htmlspecialchars($log['username']); ?>">
        <i class="fas fa-chart-line mr-1"></i>Detail
    </button>
</td>
                            <td class="py-2 px-3 align-top">
                                <?php if ($log['event_type'] == 'login'): ?>
                                    <span class="inline-flex items-center text-xs text-gray-600"><i class="fas fa-network-wired mr-1"></i><?php echo htmlspecialchars($log['ip_address'] ?? '-'); ?></span>
                                <?php else: ?>
                                    <span class="inline-flex items-center text-xs text-gray-500"><i class="fas fa-times-circle mr-1"></i><?php echo htmlspecialchars($log['last_disconnect_reason'] ?? '-'); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
            <div class="mt-4 text-right">
                <a href="logs.php" class="text-green-700 hover:underline font-semibold"><i class="fas fa-list mr-1"></i> Lihat Semua Log</a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Footer -->
    <footer class="bg-white py-4 mt-6">
        <div class="container mx-auto px-4 text-center text-gray-500 text-sm">
            &copy; <?php echo date('Y'); ?> (NotMiK) Notification Mikrotik. All rights reserved.
        </div>
    </footer>
    <!-- Modal Detail Aktivitas User-->
    <div id="modalDetail" class="fixed inset-0 z-50 hidden bg-black/40 flex items-center justify-center">
        <div class="bg-white rounded-xl shadow-lg max-w-lg w-full p-6 relative animate-fadeInUp">
            <button id="closeModal" class="absolute top-3 right-3 text-gray-400 hover:text-red-500 text-2xl font-bold focus:outline-none">&times;</button>
            <h3 class="text-xl font-bold mb-2 text-gray-800 flex items-center"><i class="fas fa-chart-bar mr-2"></i>Detail Aktivitas <span id="modalUsername" class="ml-2 text-green-700"></span></h3>
            <div id="modalChartWrap" class="my-4 min-h-[220px] flex items-center justify-center">
                <canvas id="modalChart" width="360" height="220"></canvas>
            </div>
            <div id="modalLoading" class="text-center text-gray-500 hidden">Memuat data...</div>
            <div id="modalError" class="text-center text-red-500 hidden">Gagal memuat data.</div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Script untuk copy to clipboard
        document.getElementById('copyBtn').addEventListener('click', function() {
            const scriptText = document.querySelector('pre').textContent;
            navigator.clipboard.writeText(scriptText).then(function() {
                alert('Script berhasil disalin!');
            }, function() {
                alert('Gagal menyalin script');
            });
        });

        // Modal Detail Aktivitas
        const modal = document.getElementById('modalDetail');
        const closeModalBtn = document.getElementById('closeModal');
        const modalUsername = document.getElementById('modalUsername');
        const modalChartWrap = document.getElementById('modalChartWrap');
        const modalLoading = document.getElementById('modalLoading');
        const modalError = document.getElementById('modalError');
        let modalChart = null;

        document.querySelectorAll('.detail-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const username = this.getAttribute('data-username');
                modalUsername.textContent = username;
                modal.classList.remove('hidden');
                modalLoading.classList.remove('hidden');
                modalError.classList.add('hidden');
                modalChartWrap.style.display = 'block';
                // Fetch data
                fetch(`../user-activity-history.php?username=${encodeURIComponent(username)}`)
                    .then(res => res.json())
                    .then(data => {
                        modalLoading.classList.add('hidden');
                        if (!Array.isArray(data)) {
                            modalError.classList.remove('hidden');
                            modalChartWrap.style.display = 'none';
                            return;
                        }
                        // Prepare chart
                        const labels = data.map(d => {
                            const tgl = d.date.split('-');
                            return tgl[2] + ' ' + ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'][parseInt(tgl[1])-1];
                        });
                        const login = data.map(d => d.login);
                        const logout = data.map(d => d.logout);
                        if (modalChart) modalChart.destroy();
                        const ctx = document.getElementById('modalChart').getContext('2d');
                        modalChart = new Chart(ctx, {
                            type: 'bar',
                            data: {
                                labels,
                                datasets: [
                                    {label: 'Login', data: login, backgroundColor: '#22c55e'},
                                    {label: 'Logout', data: logout, backgroundColor: '#ef4444'}
                                ]
                            },
                            options: {
                                responsive: true,
                                plugins: {legend: {position: 'top'}},
                                scales: {y: {beginAtZero: true, ticks: {precision:0}}}
                            }
                        });
                    })
                    .catch(() => {
                        modalLoading.classList.add('hidden');
                        modalError.classList.remove('hidden');
                        modalChartWrap.style.display = 'none';
                    });
            });
        });
        closeModalBtn.addEventListener('click', function() {
            modal.classList.add('hidden');
        });
        window.addEventListener('click', function(e) {
            if (e.target === modal) modal.classList.add('hidden');
        });
    </script>
    <script>
// Realtime polling log aktivitas terbaru (3 detik)
function renderLogRow(log) {
    let badge = log.event_type === 'login'
        ? `<span class=\"inline-flex items-center px-2 py-1 rounded-full bg-green-100 text-green-700 text-xs font-bold gap-1\"><i class=\"fas fa-sign-in-alt\"></i> Login</span>`
        : `<span class=\"inline-flex items-center px-2 py-1 rounded-full bg-red-100 text-red-600 text-xs font-bold gap-1\"><i class=\"fas fa-sign-out-alt\"></i> Logout</span>`;
    let ipOrReason = log.event_type === 'login'
        ? `<span class=\"inline-flex items-center text-xs text-gray-600\"><i class=\"fas fa-network-wired mr-1\"></i>${log.ip_address}</span>`
        : `<span class=\"inline-flex items-center text-xs text-gray-500\"><i class=\"fas fa-times-circle mr-1\"></i>${log.last_disconnect_reason}</span>`;
    return `<tr class=\"transition hover:bg-green-50/60 group\">\n` +
        `<td class=\"py-2 px-3 align-top\"><span class=\"text-xs text-gray-400 font-mono block leading-tight\"><i class=\"fas fa-calendar-alt mr-1\"></i>${log.tanggal}</span></td>` +
        `<td class=\"py-2 px-3 align-top\"><span class=\"text-xs text-gray-400 font-mono block leading-tight\"><i class=\"fas fa-clock mr-1\"></i>${log.waktu}</span></td>` +
        `<td class=\"py-2 px-3 align-top\">${badge}</td>` +
        `<td class=\"py-2 px-3 align-top\"><span class=\"font-semibold text-gray-800\"><i class=\"fas fa-user mr-1 text-gray-400\"></i>${log.username}</span></td>` +
        `<td class=\"py-2 px-3 align-top\">${ipOrReason}</td>` +
        `</tr>`;
}
function loadLogsRealtime() {
    fetch('logs-data.php')
        .then(res => res.json())
        .then(data => {
            if (!Array.isArray(data)) return;
            const tbody = document.getElementById('logsTbody');
            tbody.innerHTML = data.slice(0,5).map(renderLogRow).join('');
        });
}
let lastLogTimestamp = null;
function showToastNotif(msg) {
    let toast = document.createElement('div');
    toast.className = 'fixed top-6 right-6 z-50 bg-yellow-400 text-yellow-900 px-6 py-3 rounded-lg shadow-lg font-semibold text-sm animate-bounceIn';
    toast.style.transition = 'opacity 0.3s';
    toast.innerHTML = `<i class=\"fas fa-bell mr-2\"></i>${msg}`;
    document.body.appendChild(toast);
    setTimeout(() => { toast.style.opacity = 0; }, 2700);
    setTimeout(() => { toast.remove(); }, 3000);
}
function loadLogsRealtime() {
    fetch('logs-data.php')
        .then(res => res.json())
        .then(data => {
            if (!Array.isArray(data)) return;
            const tbody = document.getElementById('logsTbody');
            tbody.innerHTML = data.slice(0,5).map(renderLogRow).join('');
            if (data.length > 0) {
                let newest = data[0].waktu + ' ' + data[0].tanggal;
                if (lastLogTimestamp && newest !== lastLogTimestamp) {
                    showToastNotif('Ada aktivitas log baru!');
                }
                lastLogTimestamp = newest;
            }
        });
}
setInterval(loadLogsRealtime, 3000);
window.addEventListener('DOMContentLoaded', loadLogsRealtime);
</script>
</body>
</html>
